Brett	C.	Bushnell	-	bbushnell	-	ECE 474A
Matthew	R.	Dzurick		-	mdzurick	-	ECE 574A

November 1, 2016

Assignment 2

The purpose of this assignment is to create a C/C++
program which takes in a Netlist Behavior File
(ex. "474a_circuit1.txt") and will create a corresponding
runnable verilog .v file which corresponds to it.
This program must select which datapatch component, inputs,
wires, outputs, and all other functions to make a 100%
accurate verilog file of the pseudocode provided in the
Netlist Behavior File.